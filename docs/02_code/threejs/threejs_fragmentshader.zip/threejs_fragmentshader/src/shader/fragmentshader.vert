// THREE.JS: Handing the coordinates of the plane
// over to the fragment shader (see fragmentshader.frag)
varying vec2 vUv;

void main() {

    // THREE.JS: uv is an attribute that three.js provides for the
    // plane. It runs from 0..1 from one corner of the plane to the other.
    vUv = uv;

    vec4 modelPosition = modelMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * viewMatrix * modelPosition;
}
