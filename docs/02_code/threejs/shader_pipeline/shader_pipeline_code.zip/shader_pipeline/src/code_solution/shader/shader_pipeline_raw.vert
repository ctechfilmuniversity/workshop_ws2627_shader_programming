uniform mat4 projectionMatrix;
uniform mat4 viewMatrix;
uniform mat4 modelMatrix;

uniform float uTime;

attribute vec3 position;
attribute float aRandom;

varying float vRandom;

void main() {

    vec4 modelPosition = modelMatrix * vec4(position, 1.0);

    // modelPosition.y += sin(modelPosition.x * 20.) * 0.1;
    modelPosition.y += sin(modelPosition.x * 20. + uTime) * 0.1;
    modelPosition.y += aRandom * 0.05;

    vRandom = aRandom;

    gl_Position = projectionMatrix * viewMatrix * modelPosition;
}