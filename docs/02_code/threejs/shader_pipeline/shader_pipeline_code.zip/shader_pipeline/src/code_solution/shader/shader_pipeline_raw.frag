precision mediump float;

varying float vRandom;

void main() {

    // gl_FragColor = vec4(1., 0., 1., 1.);
    // gl_FragColor = vec4(vec3(vRandom), 1.);
    // Interpolate with the random values between two colors
    vec3 color = mix(vec3(1., 0., 1.), vec3(1.0, 0.9843, 0.0), vRandom);

    gl_FragColor = vec4(color, 1.);
}