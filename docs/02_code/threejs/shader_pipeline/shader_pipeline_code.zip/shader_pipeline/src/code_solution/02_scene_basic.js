/*
Code based on:
https://threejs-journey.com/lessons/shaders
*/

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import GUI from 'lil-gui';

import vertexShader from './shader/shader_pipeline_basic.vert';
import fragmentShader from './shader/shader_pipeline_basic.frag';

// User Menu
// const gui = new GUI();

// Canvas
const canvas = document.querySelector("#canvasThree");

// Helper
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
};

// Renderer
const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));


// Scene
const scene = new THREE.Scene();


// Geometry
const geometry = new THREE.PlaneGeometry(1, 1, 128, 128);

// Material
// const material = new THREE.MeshBasicMaterial({side: THREE.DoubleSide});
const material = new THREE.RawShaderMaterial({
    vertexShader:vertexShader,
    fragmentShader:fragmentShader,
    side: THREE.DoubleSide
});



// Mesh
const mesh = new THREE.Mesh(geometry, material);
mesh.rotation.x = - Math.PI * 0.5;
scene.add(mesh);


// Camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 0.1, 100);
camera.position.set(0.25, - 0.25, 1);
scene.add(camera);

// Controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;


// Window resize management
window.addEventListener('resize', () => {

    // Update sizes
    sizes.width = window.innerWidth;
    sizes.height = window.innerHeight;

    // Update camera
    camera.aspect = sizes.width / sizes.height;
    camera.updateProjectionMatrix();

    // Update renderer
    renderer.setSize(sizes.width, sizes.height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
});



// const timer = new THREE.Timer();

// Scene render loop
const animate = () => {

    // timer.update();
    // const elapsedTime = timer.getElapsed();

    // Update controls
    controls.update();

    // Render
    renderer.render(scene, camera);
}

// Call animate on every frame
renderer.setAnimationLoop(animate);
