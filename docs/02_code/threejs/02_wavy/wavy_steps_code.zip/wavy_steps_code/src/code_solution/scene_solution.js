/*
Code based on:
https://threejs-journey.com/lessons/shaders
*/

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import GUI from 'lil-gui';

import wavyVertexShader from './shader/wavy_solution.vert';
import wavyFragmentShader from './shader/wavy_solution.frag';

// console.log(wavyVertexShader);
// console.log(wavyFragmentShader);

// User Menu
const gui = new GUI();
const guiData = { };

// Canvas
const canvas = document.querySelector("#canvasThree");
// Helper
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
};

// Renderer
const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
renderer.setSize(sizes.width, sizes.height);


// Scene
const scene = new THREE.Scene();


// Geometry
const geometry = new THREE.PlaneGeometry(1, 1, 128, 128);

// Material
// const material = new THREE.MeshBasicMaterial({side: THREE.DoubleSide});

guiData.surfaceColor = '#00d0ff';
guiData.depthColor = '#230048';


const material = new THREE.RawShaderMaterial({
    vertexShader:wavyVertexShader,
    fragmentShader:wavyFragmentShader,
    side: THREE.DoubleSide,
    uniforms:
    {
        uTime: { value: 0 },

        uBigWavesAmplitude: { value: 0.1 },
        uBigWavesFrequency: { value: 6 },
        uBigWavesSpeed: { value: 0.75 },

        uSmallWavesAmplitude: { value: 0.15 },
        uSmallWavesFrequency: { value: 3 },
        uSmallWavesSpeed: { value: 0.2 },

        uDepthColor: { value: new THREE.Color(guiData.depthColor) },
        uSurfaceColor: { value: new THREE.Color(guiData.surfaceColor) },
        uColorOffset: { value: 0.1 },
        uColorMultiplier: { value: 8. },
    } 
});




// UI
gui.add(material.uniforms.uBigWavesAmplitude, 'value')
    .min(0).max(1).step(0.001)
    .name('Big Waves Amplitude ');

gui.add(material.uniforms.uBigWavesFrequency, 'value')
    .min(0).max(12).step(0.001)
    .name('Big Waves Frequency');

gui.add(material.uniforms.uBigWavesSpeed, 'value')
    .min(0).max(4).step(0.001)
    .name('Big Waves Speed');


gui.add(material.uniforms.uSmallWavesAmplitude, 'value')
    .min(0).max(1).step(0.001)
    .name('Small Waves Amplitude');

gui.add(material.uniforms.uSmallWavesFrequency, 'value')
    .min(0).max(30).step(0.001)
    .name('Small Waves Frequency');

gui.add(material.uniforms.uSmallWavesSpeed, 'value')
    .min(0).max(4).step(0.001)
    .name('Small Waves Speed');

gui.addColor(guiData, 'surfaceColor')
    .onChange(() => { 
        material.uniforms.uSurfaceColor.value.set(guiData.surfaceColor) 
    });

gui.addColor(guiData, 'depthColor')
    .onChange(() => { 
        material.uniforms.uDepthColor.value.set(guiData.depthColor) 
    });

gui.add(material.uniforms.uColorOffset, 'value')
    .min(0).max(1).step(0.001)
    .name('Color Offset');

gui.add(material.uniforms.uColorMultiplier, 'value')
    .min(0).max(10).step(0.001)
    .name('Color Multiplier');

// Mesh
const mesh = new THREE.Mesh(geometry, material);
// mesh.scale.set(6, 4, 2); 
mesh.rotation.x = - Math.PI * 0.25;
scene.add(mesh);

// Window resize management
window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth;
    sizes.height = window.innerHeight;

    // Update camera
    camera.aspect = sizes.width / sizes.height;
    camera.updateProjectionMatrix();

    // Update renderer
    renderer.setSize(sizes.width, sizes.height);
});


// Camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 0.1, 100);
camera.position.set(0.25, - 0.25, 1);
scene.add(camera);

// Controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;



const clock = new THREE.Clock()

// Scene render loop
const animate = () =>
{
    const elapsedTime = clock.getElapsedTime();
    material.uniforms.uTime.value = elapsedTime;

    // Update controls
    controls.update()

    // Render
    renderer.render(scene, camera)

    // Call animate again on the next frame
    window.requestAnimationFrame(animate)
}

animate()