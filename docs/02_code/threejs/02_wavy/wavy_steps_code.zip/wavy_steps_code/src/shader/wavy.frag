varying float vRandom;

void main() {

    // Interpolate with the random values between two colors
    vec3 color = mix(vec3(1., 0., 1.), vec3(1.0, 0.9843, 0.0), vRandom);

    gl_FragColor = vec4(color, 1.);
}